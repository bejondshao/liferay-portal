# AUI Alert

> Documentation and test modifications are not included in this changelog. For more details, see [full commit history](https://github.com/liferay/alloy-ui/commits/master/src/aui-alert).

## @VERSION@

No registries yet.

## [3.0.1](https://github.com/liferay/alloy-ui/releases/tag/3.0.1)

No changes.

## [3.0.0](https://github.com/liferay/alloy-ui/releases/tag/3.0.0)

* [AUI-1145](https://issues.liferay.com/browse/AUI-1145) Create Bootstrap's Alert module
