# AUI ClassNameManager

> Documentation and test modifications are not included in this changelog. For more details, see [full commit history](https://github.com/liferay/alloy-ui/commits/master/src/aui-classnamemanager).

## @VERSION@

No registries yet.

## [3.0.1](https://github.com/liferay/alloy-ui/releases/tag/3.0.1)

No changes.

## [3.0.0](https://github.com/liferay/alloy-ui/releases/tag/3.0.0)

No changes.

## [2.5.0](https://github.com/liferay/alloy-ui/releases/tag/2.5.0)

No changes.