# AUI Collection

> Documentation and test modifications are not included in this changelog. For more details, see [full commit history](https://github.com/liferay/alloy-ui/commits/master/src/aui-collection).

## @VERSION@

No registries yet.

## [3.0.1](https://github.com/liferay/alloy-ui/releases/tag/3.0.1)

No changes.

## [3.0.0](https://github.com/liferay/alloy-ui/releases/tag/3.0.0)

No changes.

## [2.5.0](https://github.com/liferay/alloy-ui/releases/tag/2.5.0)

* [AUI-1163](https://issues.liferay.com/browse/AUI-1163) Remove unnecessary constants
* [AUI-1172](https://issues.liferay.com/browse/AUI-1172) Map hashcode for object can conflict with string hashcode