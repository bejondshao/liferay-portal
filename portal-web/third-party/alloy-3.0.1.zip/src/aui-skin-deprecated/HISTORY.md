# AUI Skin Deprecated

> Documentation and test modifications are not included in this changelog. For more details, see [full commit history](https://github.com/liferay/alloy-ui/commits/master-deprecated/src/aui-skin-deprecated).

## @VERSION@

* [AUI-1779](https://issues.liferay.com/browse/AUI-1779) Active state of buttons have blurred edge in Chrome